// Tiny IndexedDB wrapper. Images are stored as Blobs so the board
// survives the original site deleting or hotlink-blocking them.

import { boardOf } from './boards.js';

const DB_NAME = 'refdrop';
const STORE = 'refs';

let dbPromise;

function openDb() {
  dbPromise ??= new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE, { keyPath: 'id' });
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbPromise;
}

async function run(mode, fn) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, mode);
    const req = fn(tx.objectStore(STORE));
    tx.oncomplete = () => resolve(req?.result);
    tx.onerror = () => reject(tx.error);
  });
}

export const addRef = (ref) => run('readwrite', (s) => s.put(ref));
export const updateRef = (ref) => run('readwrite', (s) => s.put(ref));
export const deleteRef = (id) => run('readwrite', (s) => s.delete(id));

// Newest first. Pass a board id to get only that board's refs.
export async function getRefs(boardId) {
  const refs = (await run('readonly', (s) => s.getAll())) ?? [];
  return refs.filter((r) => !boardId || boardOf(r) === boardId).sort((a, b) => b.savedAt - a.savedAt);
}

export const countRefs = async (boardId) => (await getRefs(boardId)).length;

export async function clearBoard(boardId) {
  for (const ref of await getRefs(boardId)) await deleteRef(ref.id);
}

export function domainOf(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return '';
  }
}

export function imageSrc(ref) {
  return ref.blob ? URL.createObjectURL(ref.blob) : ref.imageUrl;
}

// Let any open popup / board tab know to re-render
export function broadcastChange() {
  chrome.runtime.sendMessage({ type: 'refs-changed' }).catch(() => {});
}
