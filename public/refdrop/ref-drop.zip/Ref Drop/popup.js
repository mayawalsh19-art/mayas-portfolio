import { getRefs, updateRef, deleteRef, clearBoard, domainOf, imageSrc, broadcastChange } from './db.js';
import { exportZip } from './export.js';
import { getBoards, setActiveBoard, setCollecting, addBoard, deleteBoard, renameBoard } from './boards.js';

// Opened as a toolbar popup (older setup) rather than the side panel: give it a fixed size
if (chrome.extension?.getViews?.({ type: 'popup' }).includes(window)) document.body.classList.add('as-popup');

const main = document.getElementById('main');
const countEl = document.getElementById('count');
const clearBtn = document.getElementById('clear');
const exportBtn = document.getElementById('export');
const boardBtn = document.getElementById('board');
const boardSel = document.getElementById('boardSel');
const collectBox = document.getElementById('collect');
const hint = document.getElementById('hint');
const newBoard = document.getElementById('newBoard');
const delBoard = document.getElementById('delBoard');
const renBoard = document.getElementById('renBoard');
const renTitle = document.getElementById('renTitle');
const delMsg = document.getElementById('delMsg');
const newTitle = document.getElementById('newTitle');
const selectBtn = document.getElementById('select');
const mainBar = document.getElementById('mainBar');
const selectBar = document.getElementById('selectBar');
const deleteSelected = document.getElementById('deleteSelected');

let refs = [];
let state = { boards: [], active: null, collecting: false };
let openId = null;
let selecting = false;       // Select mode: clicking tiles ticks them for deleting
const picked = new Set();
let objectUrls = [];

function el(tag, props = {}, children = []) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}

function src(ref) {
  const url = imageSrc(ref);
  if (ref.blob) objectUrls.push(url);
  return url;
}

async function load() {
  clearTimeout(clearTimer);
  clearBtn.textContent = 'Clear all';
  // Free the old images' memory only after the new grid replaces them
  const oldUrls = objectUrls;
  objectUrls = [];
  state = await getBoards();
  renderBoardBar();
  refs = await getRefs(state.active.id);
  for (const id of picked) if (!refs.some((r) => r.id === id)) picked.delete(id);
  if (!refs.length) selecting = false;
  updateSelectUi();
  exportBtn.disabled = boardBtn.disabled = !refs.length;
  render();
  oldUrls.forEach(URL.revokeObjectURL);
}

function renderBoardBar() {
  boardSel.replaceChildren(
    ...state.boards.map((b) => el('option', { value: b.id, textContent: b.title, selected: b.id === state.active.id })),
    el('option', { value: '__new', textContent: '+ New board' }),
  );
  collectBox.checked = state.collecting;
  hint.hidden = !state.collecting;
}

function render() {
  const ref = refs.find((r) => r.id === openId);
  main.replaceChildren(ref ? renderDetail(ref) : refs.length ? renderGrid() : renderEmpty());
}

// Numbers match the board and the export: oldest ref is No. 01
const refNo = (ref) => 'No. ' + String(refs.length - refs.indexOf(ref)).padStart(2, '0');

function renderEmpty() {
  return el('div', { className: 'empty' }, [
    el('img', { src: 'logo/folder.png', alt: '' }),
    el('h2', { textContent: 'No refs yet' }),
    el('p', { innerHTML: 'Right-click any image and choose <b>Save to moodboard</b>.' }),
  ]);
}

function renderGrid() {
  return el('div', { className: 'grid' }, refs.map((ref) => {
    const tile = el('button', { className: 'tile', title: ref.pageTitle }, [
      el('img', { src: src(ref), alt: '', loading: 'lazy' }),
      el('span', { className: 'chips' }, [
        el('span', { className: 'chip no', textContent: refNo(ref) }),
        el('span', { className: 'chip src', textContent: domainOf(ref.pageUrl) }),
      ]),
    ]);
    if (Date.now() - ref.savedAt < 1500) tile.classList.add('fresh');
    if (ref.note) tile.append(el('span', { className: 'dot', title: 'Has a note' }));
    if (selecting) {
      tile.classList.toggle('picked', picked.has(ref.id));
      tile.setAttribute('aria-pressed', picked.has(ref.id));
      tile.append(el('span', { className: 'check' }));
      tile.onclick = () => {
        picked.has(ref.id) ? picked.delete(ref.id) : picked.add(ref.id);
        tile.classList.toggle('picked', picked.has(ref.id));
        tile.setAttribute('aria-pressed', picked.has(ref.id));
        updateSelectUi();
      };
      return el('div', { className: 'cell' }, [tile]);
    }
    tile.onclick = () => { openId = ref.id; updateSelectUi(); render(); };
    return el('div', { className: 'cell' }, [tile, deleteButton(ref, load)]);
  }));
}

function updateSelectUi() {
  countEl.textContent = selecting
    ? `${picked.size} selected`
    : `${refs.length} ref${refs.length === 1 ? '' : 's'}`;
  selectBtn.hidden = clearBtn.hidden = !refs.length || !!openId || selecting;
  mainBar.hidden = selecting;
  selectBar.hidden = !selecting;
  deleteSelected.disabled = !picked.size;
  deleteSelected.textContent = picked.size ? `Delete ${picked.size}` : 'Delete';
}

function setSelecting(on) {
  selecting = on;
  picked.clear();
  updateSelectUi();
  render();
}

// Two clicks to delete: the first asks "Delete?", the second removes the ref
function deleteButton(ref, after) {
  const btn = el('button', { className: 'del', textContent: '×', title: 'Delete', ariaLabel: `Delete ${refNo(ref)}` });
  btn.onclick = async () => {
    if (!btn.classList.contains('sure')) {
      btn.classList.add('sure');
      btn.textContent = 'Delete?';
      setTimeout(() => { btn.classList.remove('sure'); btn.textContent = '×'; }, 3000);
      return;
    }
    await deleteRef(ref.id);
    broadcastChange();
    after();
  };
  return btn;
}

function renderDetail(ref) {
  const back = el('button', { className: 'link-btn', textContent: '← All refs' });
  back.onclick = () => { openId = null; load(); };

  const note = el('textarea', { placeholder: 'Why did you save this? (shows up in your export)', value: ref.note });
  let timer;
  note.oninput = () => {
    clearTimeout(timer);
    timer = setTimeout(() => { ref.note = note.value.trim(); updateRef(ref); broadcastChange(); }, 300);
  };

  const visit = el('a', { className: 'btn', textContent: 'Open source', href: ref.pageUrl, target: '_blank' });
  const del = el('button', { className: 'btn', textContent: 'Remove from board' });
  del.onclick = async () => { await deleteRef(ref.id); broadcastChange(); openId = null; load(); };

  const saved = new Date(ref.savedAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });

  return el('div', { className: 'detail' }, [
    el('div', { className: 'head' }, [back, el('span', { className: 'no', textContent: refNo(ref) })]),
    el('img', { src: src(ref), alt: '' }),
    el('h2', { textContent: ref.pageTitle || domainOf(ref.pageUrl) }),
    el('div', { className: 'field' }, [
      el('span', { className: 'label', textContent: 'Source' }),
      el('a', { className: 'src', href: ref.pageUrl, target: '_blank', textContent: ref.pageUrl }),
    ]),
    el('div', { className: 'field' }, [
      el('span', { className: 'label', textContent: 'Saved' }),
      el('span', { className: 'when', textContent: saved }),
    ]),
    ...(ref.blob ? [] : [el('p', { className: 'warn', textContent: "This site blocked copying the image, so only the link was saved. It may disappear if the site removes it." })]),
    el('label', { className: 'field' }, [el('span', { className: 'label', textContent: 'Note' }), note]),
    el('div', { className: 'row' }, [visit, del]),
  ]);
}

selectBtn.onclick = () => setSelecting(true);
document.getElementById('cancelSelect').onclick = () => setSelecting(false);
document.addEventListener('keydown', (e) => { if (selecting && e.key === 'Escape') setSelecting(false); });
deleteSelected.onclick = async () => {
  for (const id of picked) await deleteRef(id);
  broadcastChange();
  setSelecting(false);
  load();
};

// Two clicks, like the × on each image. "Sure?" goes back to "Clear all" after 3 seconds.
let clearTimer;
clearBtn.onclick = async () => {
  clearTimeout(clearTimer);
  if (clearBtn.textContent !== 'Sure?') {
    clearBtn.textContent = 'Sure?';
    clearTimer = setTimeout(() => (clearBtn.textContent = 'Clear all'), 3000);
    return;
  }
  clearBtn.textContent = 'Clear all';
  await clearBoard(state.active.id);
  broadcastChange();
  load();
};
boardBtn.onclick = () => chrome.tabs.create({ url: `board.html?board=${state.active.id}` });
exportBtn.onclick = () => exportZip(state.active);

boardSel.onchange = async () => {
  delBoard.hidden = renBoard.hidden = true;
  if (boardSel.value === '__new') {
    newBoard.hidden = false;
    newTitle.focus();
    return;
  }
  openId = null;
  await setActiveBoard(boardSel.value);
  load();
};

newBoard.onsubmit = async (e) => {
  e.preventDefault();
  await addBoard(newTitle.value.trim() || 'Moodboard');
  newTitle.value = '';
  newBoard.hidden = true;
  openId = null;
  load();
};
document.getElementById('renBoardBtn').onclick = () => {
  newBoard.hidden = delBoard.hidden = true;
  renderBoardBar(); // in case the menu was left on "+ New board"
  renTitle.value = state.active.title;
  renBoard.hidden = false;
  renTitle.select();
};
document.getElementById('delBoardBtn').onclick = () => {
  newBoard.hidden = renBoard.hidden = true;
  renderBoardBar();
  const n = refs.length;
  delMsg.textContent = `Delete “${state.active.title}”` + (n ? ` and its ${n} ref${n === 1 ? '' : 's'}?` : '?');
  delBoard.hidden = false;
  delBoard.querySelector('.danger').focus();
};
delBoard.onsubmit = async (e) => {
  e.preventDefault();
  delBoard.hidden = true;
  openId = null;
  await deleteBoard(state.active.id);
  broadcastChange();
  load();
};
renBoard.onsubmit = async (e) => {
  e.preventDefault();
  renBoard.hidden = true;
  const title = renTitle.value.trim();
  if (title && title !== state.active.title) await renameBoard(state.active.id, title);
  load();
};
document.getElementById('cancelRen').onclick = () => { renBoard.hidden = true; };
document.getElementById('cancelDel').onclick = () => { delBoard.hidden = true; };
document.getElementById('cancelNew').onclick = () => { newBoard.hidden = true; renderBoardBar(); };

collectBox.onchange = async () => {
  await setCollecting(collectBox.checked);
  hint.hidden = !collectBox.checked;
  // Pages opened before the extension was installed or reloaded don't have the collect script yet
  if (collectBox.checked) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id) chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['collect.js'] }).catch(() => {});
  }
};

// The panel stays open, so keep it in step when collect mode or the board changes elsewhere
chrome.storage.onChanged.addListener((changes) => {
  if (changes.collecting || changes.activeBoardId || changes.boards) load();
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'refs-changed' && !openId) load();
});

// Until Ref Drop is pinned to the toolbar, remind people how (they can dismiss it)
async function showPinHint() {
  const pinHint = document.getElementById('pinHint');
  try {
    const { isOnToolbar } = await chrome.action.getUserSettings();
    const { pinHintDismissed } = await chrome.storage.local.get('pinHintDismissed');
    pinHint.hidden = isOnToolbar || pinHintDismissed;
  } catch {} // older Chrome: no way to tell, so stay quiet
  document.getElementById('pinDismiss').onclick = () => {
    pinHint.hidden = true;
    chrome.storage.local.set({ pinHintDismissed: true });
  };
}

load();
showPinHint();
