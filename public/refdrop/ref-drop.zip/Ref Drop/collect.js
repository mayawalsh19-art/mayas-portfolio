// Collect mode: while it's on, clicking any image on the page saves it to the active board.
// Runs on every page but does nothing until collect mode is switched on in the popup.
(() => {
  // After Ref Drop updates or reloads, Chrome leaves the old copy of this script running in
  // open tabs, cut off from the extension. Tell any older copy to shut down, then take over.
  document.dispatchEvent(new CustomEvent('refdrop:teardown'));
  const alive = () => { try { return !!chrome.runtime?.id; } catch { return false; } };

  const ICON = chrome.runtime.getURL('icons/32.png');
  const CSS = `
    :host { all: initial; }
    .wrap { position: fixed; right: 16px; bottom: 16px; z-index: 2147483647; display: grid; gap: 8px; justify-items: end;
      font: 14px/20px system-ui, -apple-system, sans-serif; }
    .bar, .toast { display: flex; align-items: center; gap: 10px; padding: 8px 8px 8px 10px; border-radius: 8px;
      background: #2E3237; color: #F8FAFB; box-shadow: 0 6px 20px rgba(17,17,17,.25); }
    .toast { padding-right: 14px; }
    img { width: 24px; height: 24px; }
    b { font-weight: 600; }
    .no { font: 700 12px/16px 'Courier New', Courier, monospace; color: #CACFD2; }
    button { font: 600 13px/18px system-ui, sans-serif; color: #111; background: #CACFD2; border: 0; border-radius: 6px; padding: 5px 10px; cursor: pointer; }
    button:focus-visible { outline: 2px solid #8CC9E8; outline-offset: 2px; }
    [hidden] { display: none !important; }
  `;
  const PAGE_CSS = `img { cursor: copy !important; }
    img:hover { outline: 3px solid #1F6A92 !important; outline-offset: -3px !important; }`;

  let on = false;
  let host, root, toastTimer;
  const pageStyle = document.createElement('style');
  pageStyle.textContent = PAGE_CSS;

  function buildUi() {
    host = document.createElement('ref-drop-collect');
    root = host.attachShadow({ mode: 'closed' });
    root.innerHTML = `<style>${CSS}</style><div class="wrap">
      <div class="toast" role="status" hidden><img src="${ICON}" alt=""><span>Saved to <b class="board"></b></span><span class="no"></span></div>
      <div class="bar"><img src="${ICON}" alt=""><span>Collecting to <b class="board"></b></span><button type="button">Stop</button></div>
    </div>`;
    root.querySelector('button').onclick = () => chrome.storage.local.set({ collecting: false });
  }

  async function sync() {
    if (!alive()) return teardown();
    const { boards, activeBoardId, boardTitle, collecting } =
      await chrome.storage.local.get(['boards', 'activeBoardId', 'boardTitle', 'collecting']);
    const board = boards?.find((b) => b.id === activeBoardId) || boards?.[0];
    on = !!collecting;
    if (on) {
      if (!host) buildUi();
      root.querySelector('.bar .board').textContent = board?.title || boardTitle || 'Moodboard';
      document.documentElement.append(host, pageStyle);
    } else {
      host?.remove();
      pageStyle.remove();
    }
  }

  // Search boxes, text fields, autocomplete dropdowns and menus are never collected from.
  // Clicking them (or a suggestion thumbnail inside them) works like normal.
  const SKIP = 'input, textarea, select, label, [contenteditable=""], [contenteditable="true"], ' +
    '[role="search"], [role="searchbox"], [role="combobox"], [role="listbox"], [role="option"], ' +
    '[role="menu"], [role="menuitem"], [role="textbox"], form[role="search"], form:has(input[type="search"])';
  const inSkipZone = (e) => e.composedPath().some((el) => el instanceof Element && el.matches(SKIP));

  // Icons, avatars and logos are too small to be refs
  const MIN_SIZE = 48;
  const bigEnough = (img) => {
    const r = img.getBoundingClientRect();
    return r.width >= MIN_SIZE && r.height >= MIN_SIZE;
  };

  // Sites often lay a transparent link or div over their images, so look under the cursor too
  function imageAt(e) {
    if (inSkipZone(e)) return null;
    let img = e.target instanceof HTMLImageElement ? e.target : null;
    if (!img) {
      const p = e.touches?.[0] || e.changedTouches?.[0] || e;
      if (p.clientX == null) return null;
      const stack = document.elementsFromPoint(p.clientX, p.clientY);
      // Only look under the cursor if nothing on top is a field or dropdown
      const i = stack.findIndex((el) => el instanceof HTMLImageElement);
      if (i < 0 || stack.slice(0, i).some((el) => el.matches(SKIP) || el.closest(SKIP))) return null;
      img = stack[i];
    }
    return img && bigEnough(img) ? img : null;
  }

  // Many sites (Pinterest included) open a pin on mouse-down or pointer-up, not on click,
  // so swallow every press on an image while collecting. You stay on the page.
  const PRESS = ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'auxclick', 'dblclick', 'dragstart', 'touchstart', 'touchend'];
  const block = (e) => {
    if (on && !alive()) return teardown();
    if (!on || e.composedPath().includes(host) || !imageAt(e)) return;
    e.preventDefault();
    e.stopImmediatePropagation();
  };
  for (const type of PRESS) window.addEventListener(type, block, { capture: true, passive: false });

  const onClick = async (e) => {
    if (on && !alive()) return teardown();
    if (!on || e.composedPath().includes(host)) return;
    const img = imageAt(e);
    let src = img?.currentSrc || img?.src;
    if (!src) return;
    e.preventDefault();
    e.stopImmediatePropagation();

    // blob: URLs only work inside this page, so turn them into data the extension can keep
    if (src.startsWith('blob:')) {
      try {
        const blob = await (await fetch(src)).blob();
        src = await new Promise((res) => { const r = new FileReader(); r.onload = () => res(r.result); r.readAsDataURL(blob); });
      } catch {}
    }

    let res;
    try {
      res = await chrome.runtime.sendMessage({ type: 'collect', srcUrl: src, pageUrl: location.href, pageTitle: document.title });
    } catch { return teardown(); }
    if (!res) return;
    const toast = root.querySelector('.toast');
    toast.querySelector('.board').textContent = res.title;
    toast.querySelector('.no').textContent = 'No. ' + String(res.no).padStart(2, '0');
    toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (toast.hidden = true), 2400);
  };
  window.addEventListener('click', onClick, true);

  const onKey = (e) => {
    if (on && !alive()) return teardown();
    // Esc in a search box clears it; it should not also stop collecting
    if (on && e.key === 'Escape' && !inSkipZone(e)) chrome.storage.local.set({ collecting: false });
  };
  document.addEventListener('keydown', onKey, true);

  const onStorage = (changes) => {
    if (changes.collecting || changes.activeBoardId || changes.boards) sync();
  };
  chrome.storage.onChanged.addListener(onStorage);

  function teardown() {
    on = false;
    host?.remove();
    pageStyle.remove();
    for (const type of PRESS) window.removeEventListener(type, block, { capture: true });
    window.removeEventListener('click', onClick, true);
    document.removeEventListener('keydown', onKey, true);
    document.removeEventListener('refdrop:teardown', teardown);
    try { chrome.storage.onChanged.removeListener(onStorage); } catch {}
  }
  document.addEventListener('refdrop:teardown', teardown);
  sync();
})();
