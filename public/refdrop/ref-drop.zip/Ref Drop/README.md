# Ref Drop

Right-click any image → **Save to moodboard**. Ref Drop keeps a copy of the image and the page it came from, so you have the source when you write your case study.

## Install (about two minutes)
Open **How to install.html** in this folder for the full guide. The short version:
1. Move this **Ref Drop** folder into Documents and keep it there. Chrome runs Ref Drop from it.
2. In Chrome, go to `chrome://extensions`.
3. Turn on **Developer mode** (top right).
4. Click **Load unpacked** and choose this folder (the one with `manifest.json` in it).
5. Pin it: click the puzzle-piece icon in the toolbar, then the pin next to Ref Drop.

To update, replace the files in this folder with the new version and click reload ↻ on Ref Drop at `chrome://extensions`. Your boards stay put.

## Use it
- **Save:** right-click an image and choose *Save to moodboard*. The icon flashes **+1** in blue.
- **Boards:** pick a board from the menu at the top of the popup, or choose *+ New board*. New saves go to the board that's selected. The pencil next to the menu renames the board; the trash deletes it and all its refs, after you confirm.
- **Collect mode:** turn on *Collect* in the popup, then just click images on any page. Each one saves to the selected board, and a message confirms the number. Turn it off in the popup, with *Stop* on the page, or by pressing Esc. Search boxes, dropdown menus and small icons are left alone, so you can still search while collecting. (Tabs that were already open before you installed or reloaded Ref Drop need a refresh first.)
- **Review:** click the Ref Drop folder icon. Ref Drop opens in Chrome's side panel and stays open while you switch tabs. Drag its edge to make it wider; close it with the × at the top of the panel. Hover a ref to see its number and source. Click it to add a note, open the source, or remove it from the board.
- **Delete:** hover any image and click **×**, then **Delete?** to confirm. To delete several, click **Select** at the top, tick the images you want gone, and click **Delete**. **Clear all** empties the whole board.
- **Board:** *Open board* shows the selected board as a moodboard sheet: title, a color palette pulled from your images, your sources, and every image numbered. Click the title to rename it. *Save as PDF* makes a PDF (a landscape moodboard page plus a credits page with clickable sources) and opens a Save window that starts on your Desktop. No print dialog.
- **Export:** *Export .zip* downloads:
  - `images/` with every image, numbered to match the board
  - `sources.csv` with page title, page URL, image URL, date saved and your note
  - `credits.md`, a ready-to-paste numbered source list

Everything stays on your computer (IndexedDB). Nothing gets uploaded.

## Notes
- If a site blocks copying an image, Ref Drop still saves the link and shows a warning in the detail view.
- Brand colors, fonts and radii are tokens at the top of `styles.css`. Fonts (Courier Prime, Hanken Grotesk) are bundled in `fonts/` under the SIL Open Font License, so it works offline.
