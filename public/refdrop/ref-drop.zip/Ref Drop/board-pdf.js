// Lays out a board as a PDF: a landscape moodboard sheet (info column + cropped image grid),
// extra image pages if it doesn't fit, then a credits page. Matches the board view's design.
import { Pdf } from './pdf.js';
import { domainOf } from './db.js';

const C = { ink: '#111111', muted: '#545A62', line: '#D3D8DC', folder: '#2E3237', link: '#1F6A92', surface: '#EEF1F3', white: '#F8FAFB' };
const W = 792, H = 612, M = 32;           // US Letter, landscape, in points
const SIDE = 170, GAP = 6;
const PX = 3;                             // image pixels per point (about 216 dpi)

const no = (i) => 'No. ' + String(i + 1).padStart(2, '0');

const measureCtx = new OffscreenCanvas(1, 1).getContext('2d');
function textWidth(str, size, font) {
  if (font === 'F3' || font === 'F4') return str.length * 0.6 * size; // Courier is monospaced
  measureCtx.font = `${font === 'F2' ? 'bold ' : ''}${size}px Helvetica, Arial, sans-serif`;
  return measureCtx.measureText(str).width;
}

// Word-wraps to maxW; words longer than a line (URLs) break anywhere
function wrap(str, maxW, size, font) {
  const lines = [];
  let line = '';
  for (const word of String(str).split(/(\s+)/)) {
    if (textWidth(line + word, size, font) <= maxW) { line += word; continue; }
    if (line.trim()) lines.push(line.trim());
    line = '';
    for (const ch of word.trimStart()) {
      if (textWidth(line + ch, size, font) > maxW) { lines.push(line); line = ''; }
      line += ch;
    }
  }
  if (line.trim()) lines.push(line.trim());
  return lines;
}

// Center-crops an image to w×h points and encodes it as JPEG
async function jpeg(source, w, h) {
  const pw = Math.round(w * PX), ph = Math.round(h * PX);
  const canvas = new OffscreenCanvas(pw, ph);
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, pw, ph);
  const sw = source.width, sh = source.height;
  const scale = Math.max(pw / sw, ph / sh);
  ctx.drawImage(source, (pw - sw * scale) / 2, (ph - sh * scale) / 2, sw * scale, sh * scale);
  const blob = await canvas.convertToBlob({ type: 'image/jpeg', quality: 0.86 });
  return { bytes: new Uint8Array(await blob.arrayBuffer()), pw, ph };
}

async function loadImage(src) {
  const img = new Image();
  img.src = src;
  await img.decode();
  return img;
}

function label(pdf, str, x, y) {
  pdf.text(str.toUpperCase(), x, y, { size: 6.5, font: 'F2', color: C.muted, spacing: 0.8 });
}

async function drawCell(pdf, ref, i, x, y, w, h) {
  try {
    const bitmap = await createImageBitmap(ref.blob);
    const { bytes, pw, ph } = await jpeg(bitmap, w, h);
    pdf.image(bytes, pw, ph, x, y, w, h, 5);
  } catch {
    // Link-only refs (the site blocked copying) get a placeholder
    pdf.rect(x, y, w, h, C.surface, 5);
    pdf.text('Image link only', x + 8, y + 16, { size: 7, color: C.muted });
  }
  const tag = no(i);
  const tw = textWidth(tag, 6.5, 'F4') + 8;
  pdf.rect(x + 5, y + h - 16, tw, 11, C.folder, 2);
  pdf.text(tag, x + 9, y + h - 8, { size: 6.5, font: 'F4', color: C.white });
}

export async function boardPdf({ title, refs, palette, bySource, summary, collected }) {
  const pdf = new Pdf(W, H);
  pdf.addPage();

  // ----- Info column -----
  let y = M;
  try {
    const logo = await loadImage('logo/lockup.svg');
    const lh = 40, lw = lh * (logo.naturalWidth / logo.naturalHeight);
    const { bytes, pw, ph } = await jpeg(logo, lw, lh);
    pdf.image(bytes, pw, ph, M, y, lw, lh);
  } catch {}
  y += 40 + 26;

  label(pdf, 'Moodboard', M, y);
  y += 22;
  for (const line of wrap(title, SIDE, 20, 'F4')) { pdf.text(line, M, y, { size: 20, font: 'F4' }); y += 22; }
  pdf.text(summary, M, y, { size: 8.5, color: C.muted });
  y += 26;

  if (palette.length) {
    label(pdf, 'Palette', M, y);
    y += 8;
    const sw = (SIDE - 2 * 4) / 3;
    palette.forEach((hex, i) => {
      const sx = M + (i % 3) * (sw + 4), sy = y + Math.floor(i / 3) * 38;
      pdf.rect(sx, sy, sw, 34, hex, 3);
      const [r, g, b] = [1, 3, 5].map((k) => parseInt(hex.slice(k, k + 2), 16));
      pdf.text(hex, sx + 4, sy + 29, { size: 5.5, font: 'F3', color: r * 0.299 + g * 0.587 + b * 0.114 > 150 ? C.ink : C.white });
    });
    y += Math.ceil(palette.length / 3) * 38 + 20;
  }

  if (bySource.length) {
    label(pdf, 'Sources', M, y);
    y += 6;
    for (const [domain, n] of bySource.slice(0, 8)) {
      y += 14;
      pdf.text(domain, M, y, { size: 7.5, font: 'F3' });
      pdf.text(String(n), M + SIDE - textWidth(String(n), 7.5, 'F3'), y, { size: 7.5, font: 'F3', color: C.muted });
      pdf.line(M, M + SIDE, y + 5, C.line);
    }
  }

  const foot = wrap(collected, SIDE, 7, 'F1');
  foot.forEach((line, i) => pdf.text(line, M, H - M - (foot.length - 1 - i) * 9, { size: 7, color: C.muted }));

  // ----- Image grid: fit the first page, continue full-width if there are more -----
  const gx = M + SIDE + 28, gw = W - M - gx, gh = H - 2 * M;
  const cols = Math.min(6, Math.max(2, Math.ceil(Math.sqrt(refs.length * 1.2))));
  const rows = Math.max(1, Math.min(5, Math.ceil(refs.length / cols)));
  const cw = (gw - (cols - 1) * GAP) / cols, ch = (gh - (rows - 1) * GAP) / rows;
  let i = 0;
  for (; i < Math.min(refs.length, cols * rows); i++) {
    await drawCell(pdf, refs[i], i, gx + (i % cols) * (cw + GAP), M + Math.floor(i / cols) * (ch + GAP), cw, ch);
  }
  const wideCols = Math.floor((W - 2 * M + GAP) / (cw + GAP));
  while (i < refs.length) {
    pdf.addPage();
    for (let k = 0; k < wideCols * rows && i < refs.length; k++, i++) {
      await drawCell(pdf, refs[i], i, M + (k % wideCols) * (cw + GAP), M + Math.floor(k / wideCols) * (ch + GAP), cw, ch);
    }
  }

  // ----- Credits -----
  pdf.addPage();
  pdf.text('Credits', M, M + 14, { size: 16, font: 'F4' });
  pdf.text(title, M, M + 28, { size: 8, color: C.muted });
  const colW = (W - 2 * M - 24) / 2, top = M + 50;
  let col = 0;
  y = top;
  refs.forEach((ref, n) => {
    const tx = M + col * (colW + 24) + 36, tw = colW - 36;
    const titleLines = wrap(ref.pageTitle || domainOf(ref.pageUrl) || 'Untitled', tw, 8, 'F2');
    const urlLines = ref.pageUrl ? wrap(ref.pageUrl, tw, 6.5, 'F3') : [];
    const noteLines = ref.note ? wrap(ref.note, tw, 7, 'F1') : [];
    const height = titleLines.length * 10 + urlLines.length * 8.5 + noteLines.length * 9 + 12;
    if (y + height > H - M) {
      col += 1;
      y = top;
      if (col > 1) { pdf.addPage(); col = 0; y = M; }
    }
    const x = M + col * (colW + 24);
    let ly = y + 8;
    pdf.text(no(n), x, ly, { size: 7.5, font: 'F4' });
    for (const line of titleLines) { pdf.text(line, x + 36, ly, { size: 8, font: 'F2' }); ly += 10; }
    const urlTop = ly;
    for (const line of urlLines) { pdf.text(line, x + 36, ly - 1, { size: 6.5, font: 'F3', color: C.link }); ly += 8.5; }
    if (urlLines.length) pdf.link(x + 36, urlTop - 8, tw, urlLines.length * 8.5, ref.pageUrl);
    for (const line of noteLines) { pdf.text(line, x + 36, ly, { size: 7, color: C.muted }); ly += 9; }
    y = ly + 2;
    pdf.line(x, x + colW, y, C.line);
    y += 8;
  });

  return pdf.bytes();
}
