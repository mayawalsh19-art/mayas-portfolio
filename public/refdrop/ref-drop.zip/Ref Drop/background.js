import { addRef, countRefs, broadcastChange } from './db.js';
import { getBoards } from './boards.js';

const MENU_ID = 'save-to-moodboard';
const GRAPHITE = '#2E3237';
const WATER = '#1F6A92';

// Clicking the toolbar icon opens Ref Drop in the side panel, which stays open while you switch tabs
chrome.action.setPopup({ popup: '' });
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

chrome.runtime.onInstalled.addListener(({ reason }) => {
  chrome.contextMenus.create({
    id: MENU_ID,
    title: 'Save to moodboard',
    contexts: ['image'],
  });
  showCount();
  // Chrome doesn't let extensions pin themselves, so show people how on first install
  if (reason === 'install') chrome.tabs.create({ url: 'welcome.html' });
});

chrome.runtime.onStartup.addListener(showCount);

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'refs-changed') showCount();
  // Collect mode: the page script sends every image the user clicks
  if (msg?.type === 'collect') {
    saveImage(msg.srcUrl, msg.pageUrl || sender.tab?.url, msg.pageTitle || sender.tab?.title).then(sendResponse);
    return true;
  }
});

chrome.storage.onChanged.addListener((changes) => {
  if (changes.activeBoardId || changes.collecting || changes.boards) showCount();
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === MENU_ID) saveImage(info.srcUrl, info.pageUrl || tab?.url, tab?.title);
});

// Saves to the active board and returns its new number, e.g. { no: 12, title: 'Futuristic Fashion' }
async function saveImage(srcUrl, pageUrl = '', pageTitle = '') {
  const { active } = await getBoards();

  // Keep a copy of the actual image; fall back to link-only if the fetch fails
  let blob = null;
  try {
    const res = await fetch(srcUrl, { credentials: 'include' });
    const data = res.ok ? await res.blob() : null;
    if (data?.type.startsWith('image/')) blob = data;
  } catch {}

  await addRef({
    id: crypto.randomUUID(),
    boardId: active.id,
    blob,
    imageUrl: srcUrl.startsWith('data:') ? '' : srcUrl,
    pageUrl,
    pageTitle,
    note: '',
    savedAt: Date.now(),
  });

  broadcastChange();
  flashSaved();
  return { no: await countRefs(active.id), title: active.title };
}

// Badge shows the active board's count; water blue while collect mode is on
async function showCount() {
  const { active, collecting } = await getBoards();
  const n = await countRefs(active.id);
  chrome.action.setBadgeBackgroundColor({ color: collecting ? WATER : GRAPHITE });
  chrome.action.setBadgeText({ text: n ? String(n) : collecting ? 'ON' : '' });
}

function flashSaved() {
  chrome.action.setBadgeBackgroundColor({ color: WATER });
  chrome.action.setBadgeText({ text: '+1' });
  setTimeout(showCount, 1200);
}
