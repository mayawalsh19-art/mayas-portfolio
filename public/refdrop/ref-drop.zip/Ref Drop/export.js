import { getRefs, domainOf } from './db.js';
import { makeZip } from './zip.js';

const EXT = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
  'image/gif': 'gif',
  'image/avif': 'avif',
  'image/svg+xml': 'svg',
};

const csvCell = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
const pad = (n) => String(n).padStart(2, '0');

// Builds ref-drop-<board>-YYYY-MM-DD.zip with images/, sources.csv and credits.md,
// numbered in board order (oldest first) so they match the board view.
export async function exportZip({ id, title: boardTitle }) {
  const refs = (await getRefs(id)).reverse();
  if (!refs.length) return;

  const enc = new TextEncoder();
  const files = [];
  const rows = [['#', 'file', 'page title', 'page url', 'image url', 'saved', 'note']];
  const credits = [`# ${boardTitle} — sources`, ''];

  for (const [i, ref] of refs.entries()) {
    const num = pad(i + 1);
    const domain = domainOf(ref.pageUrl) || 'image';
    let fileName = '';
    if (ref.blob) {
      fileName = `images/${num}-${domain}.${EXT[ref.blob.type] ?? 'img'}`;
      files.push({ name: fileName, data: new Uint8Array(await ref.blob.arrayBuffer()) });
    }
    const saved = new Date(ref.savedAt).toISOString().slice(0, 10);
    rows.push([num, fileName || '(link only)', ref.pageTitle, ref.pageUrl, ref.imageUrl, saved, ref.note]);
    const title = ref.pageTitle || domain;
    credits.push(`${i + 1}. [${title}](${ref.pageUrl})${ref.note ? ` — ${ref.note}` : ''}`);
  }

  files.push({ name: 'sources.csv', data: enc.encode(rows.map((r) => r.map(csvCell).join(',')).join('\n')) });
  files.push({ name: 'credits.md', data: enc.encode(credits.join('\n') + '\n') });

  const blob = new Blob([makeZip(files)], { type: 'application/zip' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  const slug = boardTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'board';
  a.download = `ref-drop-${slug}-${new Date().toISOString().slice(0, 10)}.zip`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 10_000);
}
