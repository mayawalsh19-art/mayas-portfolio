// Minimal PDF writer, no dependencies: JPEG images, filled shapes, hairlines, links, and text
// in the built-in Helvetica and Courier fonts. Coordinates are points from the top-left.

const FONTS = { F1: 'Helvetica', F2: 'Helvetica-Bold', F3: 'Courier', F4: 'Courier-Bold' };

// Characters outside Latin-1 that the PDF's WinAnsi encoding still has
const WIN_ANSI = { '–': 0x96, '—': 0x97, '‘': 0x91, '’': 0x92, '“': 0x93, '”': 0x94, '•': 0x95, '…': 0x85, '€': 0x80 };

const num = (n) => +n.toFixed(2);
const hexText = (s) => '<' + [...String(s)].map((ch) => {
  const code = WIN_ANSI[ch] ?? ch.charCodeAt(0);
  return (code < 256 ? code : 63).toString(16).padStart(2, '0');
}).join('') + '>';
const rgb = (hex) => [1, 3, 5].map((i) => num(parseInt(hex.slice(i, i + 2), 16) / 255)).join(' ');
const latin1 = (s) => Uint8Array.from(s, (c) => c.charCodeAt(0) & 255);

// Rounded-rectangle path in PDF coordinates (origin bottom-left)
function roundRect(x, y, w, h, r) {
  const k = 0.5523 * r;
  return [
    `${num(x + r)} ${num(y)} m ${num(x + w - r)} ${num(y)} l`,
    `${num(x + w - r + k)} ${num(y)} ${num(x + w)} ${num(y + r - k)} ${num(x + w)} ${num(y + r)} c ${num(x + w)} ${num(y + h - r)} l`,
    `${num(x + w)} ${num(y + h - r + k)} ${num(x + w - r + k)} ${num(y + h)} ${num(x + w - r)} ${num(y + h)} c ${num(x + r)} ${num(y + h)} l`,
    `${num(x + r - k)} ${num(y + h)} ${num(x)} ${num(y + h - r + k)} ${num(x)} ${num(y + h - r)} c ${num(x)} ${num(y + r)} l`,
    `${num(x)} ${num(y + r - k)} ${num(x + r - k)} ${num(y)} ${num(x + r)} ${num(y)} c h`,
  ].join(' ');
}

export class Pdf {
  constructor(width = 792, height = 612) {
    this.w = width;
    this.h = height;
    this.pages = [];
    this.images = [];
  }

  addPage() {
    this.page = { ops: [], links: [] };
    this.pages.push(this.page);
  }

  #box(x, y, w, h, r) {
    const by = this.h - y - h;
    return r ? roundRect(x, by, w, h, r) : `${num(x)} ${num(by)} ${num(w)} ${num(h)} re`;
  }

  rect(x, y, w, h, color, r = 0) {
    this.page.ops.push(`${rgb(color)} rg ${this.#box(x, y, w, h, r)} f`);
  }

  line(x1, x2, y, color, width = 0.5) {
    const py = num(this.h - y);
    this.page.ops.push(`${rgb(color)} RG ${width} w ${num(x1)} ${py} m ${num(x2)} ${py} l S`);
  }

  // jpeg: the encoded bytes; px: its pixel size; drawn into the box, clipped to rounded corners
  image(jpeg, pxW, pxH, x, y, w, h, r = 0) {
    const name = `Im${this.images.length}`;
    this.images.push({ name, jpeg, pxW, pxH });
    this.page.ops.push(`q ${this.#box(x, y, w, h, r)} W n ${num(w)} 0 0 ${num(h)} ${num(x)} ${num(this.h - y - h)} cm /${name} Do Q`);
  }

  // y is the text baseline; font is F1 Helvetica, F2 Helvetica-Bold, F3 Courier, F4 Courier-Bold
  text(str, x, y, { size = 10, font = 'F1', color = '#111111', spacing = 0 } = {}) {
    this.page.ops.push(`BT /${font} ${size} Tf ${spacing} Tc ${rgb(color)} rg ${num(x)} ${num(this.h - y)} Td ${hexText(str)} Tj ET`);
  }

  link(x, y, w, h, url) {
    this.page.links.push({ rect: [x, this.h - y - h, x + w, this.h - y].map(num).join(' '), url });
  }

  bytes() {
    const chunks = [];
    const offsets = [];
    let length = 0;
    const push = (d) => { const b = typeof d === 'string' ? latin1(d) : d; chunks.push(b); length += b.length; };
    const obj = (n, parts) => { offsets[n] = length; push(`${n} 0 obj\n`); [].concat(parts).forEach(push); push('\nendobj\n'); };

    let next = 3;
    const fontRef = Object.fromEntries(Object.keys(FONTS).map((k) => [k, next++]));
    const imageRef = this.images.map(() => next++);
    const pageRef = this.pages.map(() => { const n = next; next += 2; return n; });

    push('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n');
    obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
    obj(2, `<< /Type /Pages /Kids [${pageRef.map((n) => `${n} 0 R`).join(' ')}] /Count ${pageRef.length} >>`);
    for (const [k, base] of Object.entries(FONTS)) {
      obj(fontRef[k], `<< /Type /Font /Subtype /Type1 /BaseFont /${base} /Encoding /WinAnsiEncoding >>`);
    }
    this.images.forEach((im, i) => obj(imageRef[i], [
      `<< /Type /XObject /Subtype /Image /Width ${im.pxW} /Height ${im.pxH} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${im.jpeg.length} >>\nstream\n`,
      im.jpeg, '\nendstream',
    ]));
    const resources = `<< /Font << ${Object.keys(FONTS).map((k) => `/${k} ${fontRef[k]} 0 R`).join(' ')} >> `
      + `/XObject << ${this.images.map((im, i) => `/${im.name} ${imageRef[i]} 0 R`).join(' ')} >> >>`;
    this.pages.forEach((p, i) => {
      const annots = p.links.map((l) => `<< /Type /Annot /Subtype /Link /Rect [${l.rect}] /Border [0 0 0] /A << /S /URI /URI ${hexText(l.url)} >> >>`);
      obj(pageRef[i], `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${this.w} ${this.h}] /Resources ${resources} /Contents ${pageRef[i] + 1} 0 R`
        + (annots.length ? ` /Annots [${annots.join(' ')}]` : '') + ' >>');
      const content = p.ops.join('\n');
      obj(pageRef[i] + 1, [`<< /Length ${content.length} >>\nstream\n`, content, '\nendstream']);
    });

    const xref = length;
    push(`xref\n0 ${next}\n0000000000 65535 f \n` + offsets.slice(1).map((o) => `${String(o).padStart(10, '0')} 00000 n \n`).join(''));
    push(`trailer\n<< /Size ${next} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`);

    const out = new Uint8Array(length);
    let at = 0;
    for (const c of chunks) { out.set(c, at); at += c.length; }
    return out;
  }
}
