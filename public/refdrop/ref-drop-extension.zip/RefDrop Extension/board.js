import { getRefs, deleteRef, broadcastChange, domainOf, imageSrc } from './db.js';
import { exportZip } from './export.js';
import { getBoards, renameBoard } from './boards.js';
import { boardPdf } from './board-pdf.js';

const title = document.getElementById('title');
const sub = document.getElementById('sub');
const grid = document.getElementById('grid');
const made = document.getElementById('made');

let objectUrls = [];
const current = { refs: [], bySource: [], palette: [] }; // what Save as PDF draws

function el(tag, props = {}, children = []) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}

const no = (i) => 'No. ' + String(i + 1).padStart(2, '0');
const day = (t, opts) => new Date(t).toLocaleDateString(undefined, { month: 'short', day: 'numeric', ...opts });

async function render() {
  objectUrls.forEach(URL.revokeObjectURL);
  objectUrls = [];
  // Oldest first, so numbers stay stable as you add more
  const refs = (await getRefs(board.id)).reverse();
  const urls = refs.map((ref) => {
    const url = imageSrc(ref);
    if (ref.blob) objectUrls.push(url);
    return url;
  });

  const bySource = new Map();
  for (const ref of refs) {
    const d = domainOf(ref.pageUrl) || 'unknown';
    bySource.set(d, (bySource.get(d) || 0) + 1);
  }
  sub.textContent = `${refs.length} ref${refs.length === 1 ? '' : 's'} from ${bySource.size} source${bySource.size === 1 ? '' : 's'}`;

  const times = refs.map((r) => r.savedAt);
  made.textContent = refs.length
    ? `Collected ${day(Math.min(...times))}${day(Math.min(...times)) === day(Math.max(...times)) ? '' : ' – ' + day(Math.max(...times))}, ${new Date(Math.max(...times)).getFullYear()} with Ref Drop`
    : '';

  current.refs = refs;
  current.bySource = [...bySource].sort((a, b) => b[1] - a[1]);
  document.getElementById('sourcesBox').hidden = !refs.length;
  document.getElementById('sources').replaceChildren(...current.bySource.slice(0, 8)
    .map(([d, n]) => el('li', {}, [el('span', { textContent: d }), el('span', { className: 'n', textContent: n })])));

  // For Save as PDF: a cropped grid sized so the whole board fits one landscape sheet
  const cols = Math.min(6, Math.max(2, Math.ceil(Math.sqrt(refs.length * 1.2))));
  grid.style.setProperty('--cols', cols);
  grid.style.setProperty('--rows', Math.min(5, Math.ceil(refs.length / cols)));

  grid.replaceChildren(...(refs.length ? refs.map((ref, i) => {
    const fig = el('figure', {}, [
      el('div', { className: 'frame' }, [
        el('img', { src: urls[i], alt: ref.note || ref.pageTitle || '' }),
        el('span', { className: 'num', textContent: no(i) }),
        el('a', { className: 'src', href: ref.pageUrl, target: '_blank', textContent: domainOf(ref.pageUrl) }),
      ]),
      deleteButton(ref),
    ]);
    if (ref.note) fig.append(el('figcaption', { textContent: ref.note }));
    return fig;
  }) : [el('p', { className: 'board-empty', textContent: 'No refs on this board yet. Right-click any image and choose Save to moodboard, or turn on Collect.' })]));

  document.getElementById('credits').replaceChildren(...refs.map((ref, i) => el('li', {}, [
    el('span', { className: 'num', textContent: no(i) }),
    el('div', {}, [
      el('b', { textContent: ref.pageTitle || domainOf(ref.pageUrl) }),
      el('a', { href: ref.pageUrl, textContent: ref.pageUrl }),
      ...(ref.note ? [el('span', { className: 'note', textContent: ref.note })] : []),
    ]),
  ])));

  renderPalette(urls);
}

// The board's colors: sample every image small, bucket the pixels, keep the most common distinct ones
async function renderPalette(urls) {
  const canvas = Object.assign(document.createElement('canvas'), { width: 40, height: 40 });
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  const counts = new Map();
  for (const url of urls.slice(0, 30)) {
    try {
      const img = await new Promise((res, rej) => Object.assign(new Image(), { onload() { res(this); }, onerror: rej, src: url }));
      ctx.drawImage(img, 0, 0, 40, 40);
      const d = ctx.getImageData(0, 0, 40, 40).data;
      for (let i = 0; i < d.length; i += 4) {
        const key = ((d[i] >> 4) << 8) | ((d[i + 1] >> 4) << 4) | (d[i + 2] >> 4);
        counts.set(key, (counts.get(key) || 0) + 1);
      }
    } catch {} // Link-only refs from other sites can't be read; skip them
  }
  const picked = [];
  for (const [key] of [...counts].sort((a, b) => b[1] - a[1])) {
    const rgb = [(key >> 8) & 15, (key >> 4) & 15, key & 15].map((v) => v * 16 + 8);
    if (picked.every((p) => Math.hypot(p[0] - rgb[0], p[1] - rgb[1], p[2] - rgb[2]) > 70)) picked.push(rgb);
    if (picked.length === 6) break;
  }
  const hex = (rgb) => '#' + rgb.map((v) => v.toString(16).padStart(2, '0')).join('').toUpperCase();
  current.palette = picked.map(hex);
  document.getElementById('paletteBox').hidden = !picked.length;
  document.getElementById('palette').replaceChildren(...picked.map((rgb) => {
    const light = rgb[0] * 0.299 + rgb[1] * 0.587 + rgb[2] * 0.114 > 150;
    const swatch = el('div', { className: 'swatch' + (light ? ' light' : '') }, [el('span', { textContent: hex(rgb) })]);
    swatch.style.background = hex(rgb);
    return swatch;
  }));
}

const { boards, active } = await getBoards();
const board = boards.find((b) => b.id === new URLSearchParams(location.search).get('board')) || active;

// Two clicks to delete: the first asks "Delete?", the second removes the ref
function deleteButton(ref) {
  const btn = Object.assign(document.createElement('button'), { className: 'del', textContent: '×', title: 'Delete' });
  btn.setAttribute('aria-label', 'Delete this ref');
  btn.onclick = async () => {
    if (!btn.classList.contains('sure')) {
      btn.classList.add('sure');
      btn.textContent = 'Delete?';
      setTimeout(() => { btn.classList.remove('sure'); btn.textContent = '×'; }, 3000);
      return;
    }
    await deleteRef(ref.id);
    broadcastChange();
    render();
  };
  return btn;
}

title.textContent = board.title;
document.title = `${title.textContent} — Ref Drop`;
title.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); title.blur(); } });
title.addEventListener('blur', () => {
  const boardTitle = title.textContent.trim() || 'Moodboard';
  title.textContent = boardTitle;
  document.title = `${boardTitle} — Ref Drop`;
  board.title = boardTitle;
  renameBoard(board.id, boardTitle);
});

// Builds the PDF in the extension and opens a Save window that starts on the Desktop
const saveBtn = document.getElementById('print');
saveBtn.onclick = async () => {
  saveBtn.disabled = true;
  saveBtn.textContent = 'Making PDF…';
  try {
    const bytes = await boardPdf({
      title: board.title,
      refs: current.refs,
      palette: current.palette,
      bySource: current.bySource,
      summary: sub.textContent,
      collected: made.textContent,
    });
    await saveFile(new Blob([bytes], { type: 'application/pdf' }), `${board.title} moodboard.pdf`);
  } finally {
    saveBtn.disabled = false;
    saveBtn.textContent = 'Save as PDF';
  }
};

async function saveFile(blob, name) {
  if (window.showSaveFilePicker) {
    try {
      const handle = await window.showSaveFilePicker({
        suggestedName: name, startIn: 'desktop', types: [{ description: 'PDF', accept: { 'application/pdf': ['.pdf'] } }],
      });
      const out = await handle.createWritable();
      await out.write(blob);
      await out.close();
    } catch (e) {
      if (e.name !== 'AbortError') throw e; // AbortError: they closed the Save window
    }
    return;
  }
  const a = Object.assign(document.createElement('a'), { href: URL.createObjectURL(blob), download: name });
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 10_000);
}
document.getElementById('export').onclick = () => exportZip(board);

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'refs-changed') render();
});

render();
