// Boards live in chrome.storage.local; each ref points at one with ref.boardId.
// Refs saved before boards existed have no boardId and belong to the default board.

export const DEFAULT_ID = 'default';
export const boardOf = (ref) => ref.boardId || DEFAULT_ID;

export async function getBoards() {
  const { boards, boardTitle, activeBoardId, collecting } =
    await chrome.storage.local.get(['boards', 'boardTitle', 'activeBoardId', 'collecting']);
  const list = boards?.length ? boards : [{ id: DEFAULT_ID, title: boardTitle || 'Moodboard' }];
  const active = list.find((b) => b.id === activeBoardId) || list[0];
  return { boards: list, active, collecting: !!collecting };
}

export const setActiveBoard = (id) => chrome.storage.local.set({ activeBoardId: id });
export const setCollecting = (on) => chrome.storage.local.set({ collecting: on });

export async function addBoard(title) {
  const { boards } = await getBoards();
  const board = { id: crypto.randomUUID(), title };
  await chrome.storage.local.set({ boards: [...boards, board], activeBoardId: board.id });
  return board;
}

export async function renameBoard(id, title) {
  const { boards } = await getBoards();
  await chrome.storage.local.set({ boards: boards.map((b) => (b.id === id ? { ...b, title } : b)) });
}
