// Collect mode: while it's on, clicking any image on the page saves it to the active board.
// Runs on every page but does nothing until collect mode is switched on in the popup.
(() => {
  if (window.__refDropCollect) return;
  window.__refDropCollect = true;

  const ICON = chrome.runtime.getURL('icons/32.png');
  const CSS = `
    :host { all: initial; }
    .wrap { position: fixed; right: 16px; bottom: 16px; z-index: 2147483647; display: grid; gap: 8px; justify-items: end;
      font: 14px/20px system-ui, -apple-system, sans-serif; }
    .bar, .toast { display: flex; align-items: center; gap: 10px; padding: 8px 8px 8px 10px; border-radius: 8px;
      background: #2E3237; color: #F8FAFB; box-shadow: 0 6px 20px rgba(17,17,17,.25); }
    .toast { padding-right: 14px; }
    img { width: 24px; height: 24px; }
    b { font-weight: 600; }
    .no { font: 700 12px/16px 'Courier New', Courier, monospace; color: #CACFD2; }
    button { font: 600 13px/18px system-ui, sans-serif; color: #111; background: #CACFD2; border: 0; border-radius: 6px; padding: 5px 10px; cursor: pointer; }
    button:focus-visible { outline: 2px solid #8CC9E8; outline-offset: 2px; }
    [hidden] { display: none !important; }
  `;
  const PAGE_CSS = `img { cursor: copy !important; }
    img:hover { outline: 3px solid #1F6A92 !important; outline-offset: -3px !important; }`;

  let on = false;
  let host, root, toastTimer;
  const pageStyle = document.createElement('style');
  pageStyle.textContent = PAGE_CSS;

  function buildUi() {
    host = document.createElement('ref-drop-collect');
    root = host.attachShadow({ mode: 'closed' });
    root.innerHTML = `<style>${CSS}</style><div class="wrap">
      <div class="toast" role="status" hidden><img src="${ICON}" alt=""><span>Saved to <b class="board"></b></span><span class="no"></span></div>
      <div class="bar"><img src="${ICON}" alt=""><span>Collecting to <b class="board"></b></span><button type="button">Stop</button></div>
    </div>`;
    root.querySelector('button').onclick = () => chrome.storage.local.set({ collecting: false });
  }

  async function sync() {
    const { boards, activeBoardId, boardTitle, collecting } =
      await chrome.storage.local.get(['boards', 'activeBoardId', 'boardTitle', 'collecting']);
    const board = boards?.find((b) => b.id === activeBoardId) || boards?.[0];
    on = !!collecting;
    if (on) {
      if (!host) buildUi();
      root.querySelector('.bar .board').textContent = board?.title || boardTitle || 'Moodboard';
      document.documentElement.append(host, pageStyle);
    } else {
      host?.remove();
      pageStyle.remove();
    }
  }

  // Sites often lay a transparent link or div over their images, so look under the cursor too
  function imageAt(e) {
    if (e.target instanceof HTMLImageElement) return e.target;
    const p = e.touches?.[0] || e.changedTouches?.[0] || e;
    if (p.clientX == null) return null;
    return document.elementsFromPoint(p.clientX, p.clientY).find((el) => el instanceof HTMLImageElement);
  }

  // Many sites (Pinterest included) open a pin on mouse-down or pointer-up, not on click,
  // so swallow every press on an image while collecting. You stay on the page.
  const PRESS = ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'auxclick', 'dblclick', 'dragstart', 'touchstart', 'touchend'];
  const block = (e) => {
    if (!on || e.composedPath().includes(host) || !imageAt(e)) return;
    e.preventDefault();
    e.stopImmediatePropagation();
  };
  for (const type of PRESS) window.addEventListener(type, block, { capture: true, passive: false });

  window.addEventListener('click', async (e) => {
    if (!on || e.composedPath().includes(host)) return;
    const img = imageAt(e);
    const src = img?.currentSrc || img?.src;
    if (!src) return;
    e.preventDefault();
    e.stopImmediatePropagation();

    const res = await chrome.runtime.sendMessage({ type: 'collect', srcUrl: src, pageUrl: location.href, pageTitle: document.title });
    const toast = root.querySelector('.toast');
    toast.querySelector('.board').textContent = res.title;
    toast.querySelector('.no').textContent = 'No. ' + String(res.no).padStart(2, '0');
    toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (toast.hidden = true), 2400);
  }, true);

  document.addEventListener('keydown', (e) => {
    if (on && e.key === 'Escape') chrome.storage.local.set({ collecting: false });
  }, true);

  chrome.storage.onChanged.addListener((changes) => {
    if (changes.collecting || changes.activeBoardId || changes.boards) sync();
  });
  sync();
})();
